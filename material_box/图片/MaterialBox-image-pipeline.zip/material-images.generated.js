// Auto-generated image entries will be written here by:
// python tools/fetch_material_images.py apply
window.MATERIAL_IMAGE_MAP = Object.assign({}, window.MATERIAL_IMAGE_MAP || {}, {});
