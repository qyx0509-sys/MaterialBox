/*
 * MaterialBox — 简易材料百科网站
 *
 * 该脚本包含示例数据和渲染逻辑，用于实现基本的分类浏览、搜索和详情查看功能。
 */

// 示例材料数据。后续可从服务器或数据库加载。
const materialsData = [
  {
    id: "steel",
    name_cn: "钢",
    name_en: "Steel",
    abbreviation: null,
    category_1: "金属材料",
    category_2: "铁基合金",
    description:
      "钢是铁与碳为主要元素组成的合金，具有良好的综合力学性能和可加工性，是使用最广泛的工程材料之一。",
    properties: ["高强度", "塑性好", "可焊接", "可热处理"],
    applications: [
      "建筑结构",
      "机械零件",
      "车辆与船舶",
      "工具与模具",
    ],
    advantages: ["成本低", "性能可调", "资源丰富"],
    disadvantages: ["易腐蚀", "密度较大"],
    processing_methods: ["锻造", "轧制", "铸造", "焊接"],
    related_materials: ["不锈钢", "铸铁"],
    tags: ["结构材料", "成本低"]
  },
  {
    id: "aluminium_alloy",
    name_cn: "铝合金",
    name_en: "Aluminium Alloy",
    abbreviation: null,
    category_1: "金属材料",
    category_2: "轻合金",
    description:
      "铝合金是以铝为基加入其他合金元素制成的材料，具有密度小、导电导热性好、耐腐蚀性等特点。",
    properties: ["轻质", "导热性好", "导电性好", "耐腐蚀"],
    applications: ["航空航天", "交通运输", "建筑", "包装"],
    advantages: ["密度小", "塑性好", "可回收"],
    disadvantages: ["强度较低", "耐磨性差"],
    processing_methods: ["挤压", "轧制", "铸造", "焊接"],
    related_materials: ["镁合金", "钛合金"],
    tags: ["轻质", "耐腐蚀"]
  },
  {
    id: "titanium_alloy",
    name_cn: "钛合金",
    name_en: "Titanium Alloy",
    abbreviation: null,
    category_1: "金属材料",
    category_2: "轻合金",
    description:
      "钛合金具有高比强度、良好的耐腐蚀性和耐热性，广泛用于航空航天和海洋工程。",
    properties: ["高比强度", "耐腐蚀", "耐高温"],
    applications: ["航空发动机", "海水设备", "医疗植入物"],
    advantages: ["重量轻", "生物相容性好", "耐腐蚀"],
    disadvantages: ["成本高", "加工困难"],
    processing_methods: ["锻造", "轧制", "焊接", "3D打印"],
    related_materials: ["铝合金", "镁合金"],
    tags: ["高性能", "耐腐蚀"]
  },
  {
    id: "magnesium_alloy",
    name_cn: "镁合金",
    name_en: "Magnesium Alloy",
    abbreviation: null,
    category_1: "金属材料",
    category_2: "轻合金",
    description:
      "镁合金是最轻的结构金属材料之一，具有优良的比强度和减震性能，用于汽车、电子等领域。",
    properties: ["超轻", "良好阻尼性", "易加工"],
    applications: ["汽车部件", "笔记本壳体", "航空航天"],
    advantages: ["密度最低", "切削性好"],
    disadvantages: ["易燃", "耐腐蚀性差"],
    processing_methods: ["压铸", "挤压", "焊接"],
    related_materials: ["铝合金", "钛合金"],
    tags: ["轻质", "阻尼"]
  },
  {
    id: "copper_alloy",
    name_cn: "铜合金",
    name_en: "Copper Alloy",
    abbreviation: null,
    category_1: "金属材料",
    category_2: "导电导热合金",
    description:
      "铜合金以铜为基加入锡、锌、铝等元素，具有优良的导电、导热性和抗腐蚀性能。",
    properties: ["导电性好", "导热性好", "耐腐蚀"],
    applications: ["电气元件", "换热器", "管道"],
    advantages: ["加工性好", "耐磨"],
    disadvantages: ["密度较大", "成本较高"],
    processing_methods: ["挤压", "轧制", "铸造", "焊接"],
    related_materials: ["铝合金", "镍合金"],
    tags: ["导电", "导热"]
  },
  {
    id: "stainless_steel",
    name_cn: "不锈钢",
    name_en: "Stainless Steel",
    abbreviation: null,
    category_1: "金属材料",
    category_2: "铁基合金",
    description:
      "不锈钢含有较高的铬和镍，具有良好的耐腐蚀性和装饰性，常用于餐具、设备和建筑装饰。",
    properties: ["耐腐蚀", "强度高", "表面光亮"],
    applications: ["厨房用品", "化工设备", "建筑装饰"],
    advantages: ["抗腐蚀", "清洁美观"],
    disadvantages: ["成本高", "导热性差"],
    processing_methods: ["轧制", "焊接", "抛光"],
    related_materials: ["钢", "铁铬合金"],
    tags: ["耐腐蚀", "装饰"]
  },
  {
    id: "polyethylene",
    name_cn: "聚乙烯",
    name_en: "Polyethylene",
    abbreviation: "PE",
    category_1: "高分子材料",
    category_2: "通用塑料",
    description:
      "聚乙烯是一种结晶度高、非极性的热塑性树脂，具有优异的耐化学性和电绝缘性能。",
    properties: ["耐腐蚀", "绝缘", "柔韧", "易加工"],
    applications: ["薄膜", "容器", "管材", "电线电缆"],
    advantages: ["成本低", "化学稳定性好"],
    disadvantages: ["耐热性差", "易老化"],
    processing_methods: ["挤出", "注塑", "吹塑"],
    related_materials: ["聚丙烯", "聚氯乙烯"],
    tags: ["塑料", "低成本"]
  },
  {
    id: "polypropylene",
    name_cn: "聚丙烯",
    name_en: "Polypropylene",
    abbreviation: "PP",
    category_1: "高分子材料",
    category_2: "通用塑料",
    description:
      "聚丙烯是一种半结晶的热塑性塑料，具有优良的力学性能和耐化学性，是应用广泛的塑料之一。",
    properties: ["强度高", "耐疲劳", "抗化学"],
    applications: ["家电外壳", "汽车零件", "纤维", "包装容器"],
    advantages: ["密度低", "机械性能好"],
    disadvantages: ["易脆化", "耐寒性差"],
    processing_methods: ["注塑", "挤出", "纺丝"],
    related_materials: ["聚乙烯", "聚苯乙烯"],
    tags: ["塑料", "轻质"]
  },
  {
    id: "polyvinyl_chloride",
    name_cn: "聚氯乙烯",
    name_en: "Polyvinyl Chloride",
    abbreviation: "PVC",
    category_1: "高分子材料",
    category_2: "通用塑料",
    description:
      "聚氯乙烯是一种含氯量高的热塑性塑料，兼具阻燃性和优良的耐化学性，常用于管材、门窗等。",
    properties: ["阻燃", "耐腐蚀", "绝缘"],
    applications: ["建筑管材", "门窗型材", "电缆绝缘"],
    advantages: ["成本低", "阻燃"],
    disadvantages: ["低温脆化", "环保争议"],
    processing_methods: ["挤出", "注塑", "压延"],
    related_materials: ["聚乙烯", "聚丙烯"],
    tags: ["塑料", "阻燃"]
  },
  {
    id: "polycarbonate",
    name_cn: "聚碳酸酯",
    name_en: "Polycarbonate",
    abbreviation: "PC",
    category_1: "高分子材料",
    category_2: "工程塑料",
    description:
      "聚碳酸酯是一种透明的工程塑料，具有优异的抗冲击性、耐热性和光学性能，被称为无声的钢。",
    properties: ["高透明", "耐冲击", "耐热"],
    applications: ["光盘", "防护板", "汽车灯罩", "电子设备外壳"],
    advantages: ["强度高", "尺寸稳定"],
    disadvantages: ["耐刮性差", "易应力开裂"],
    processing_methods: ["注塑", "挤出", "吹塑"],
    related_materials: ["ABS", "尼龙"],
    tags: ["工程塑料", "透明"]
  },
  {
    id: "nylon",
    name_cn: "尼龙",
    name_en: "Polyamide",
    abbreviation: "PA",
    category_1: "高分子材料",
    category_2: "工程塑料",
    description:
      "尼龙是一类含有重复酰胺键的高分子材料，具有良好的耐磨性和自润滑性，用途广泛。",
    properties: ["高强度", "耐磨", "耐疲劳"],
    applications: ["齿轮", "轴承", "纤维", "汽车部件"],
    advantages: ["韧性好", "自润滑"],
    disadvantages: ["吸水性高", "尺寸稳定性差"],
    processing_methods: ["注塑", "挤出", "纺丝"],
    related_materials: ["POM", "PET"],
    tags: ["工程塑料", "耐磨"]
  },
  {
    id: "peek",
    name_cn: "聚醚醚酮",
    name_en: "Polyether ether ketone",
    abbreviation: "PEEK",
    category_1: "高分子材料",
    category_2: "特种工程塑料",
    description:
      "PEEK 是一种高性能热塑性工程塑料，具有优异的耐高温、耐化学腐蚀和机械性能。",
    properties: ["耐高温", "耐化学", "高强度"],
    applications: ["医疗植入物", "航空航天零件", "汽车零部件"],
    advantages: ["综合性能优异", "可以替代金属"],
    disadvantages: ["价格昂贵", "加工温度高"],
    processing_methods: ["注塑", "挤出", "机加工", "3D打印"],
    related_materials: ["PI", "PPS"],
    tags: ["高性能", "耐高温"]
  },
  {
    id: "pi",
    name_cn: "聚酰亚胺",
    name_en: "Polyimide",
    abbreviation: "PI",
    category_1: "高分子材料",
    category_2: "特种工程塑料",
    description:
      "聚酰亚胺是一类耐高温高分子材料，具有优异的热稳定性和电绝缘性，被广泛用于航空航天和电子工业。",
    properties: ["耐高温", "绝缘性好", "尺寸稳定"],
    applications: ["柔性电路", "耐高温绝缘件", "航空部件"],
    advantages: ["耐热性最高", "耐辐射"],
    disadvantages: ["加工困难", "成本高"],
    processing_methods: ["涂覆", "热压", "3D打印"],
    related_materials: ["PEEK", "PPS"],
    tags: ["高性能", "绝缘"]
  },
  {
    id: "alumina_ceramic",
    name_cn: "氧化铝陶瓷",
    name_en: "Alumina Ceramic",
    abbreviation: null,
    category_1: "无机非金属材料",
    category_2: "陶瓷",
    description:
      "氧化铝陶瓷硬度高、耐磨损、耐高温，广泛用于机械密封、切削工具和电绝缘件。",
    properties: ["高硬度", "耐磨", "耐高温", "绝缘"],
    applications: ["轴承", "切削刀具", "电子基板", "生物陶瓷"],
    advantages: ["耐磨损", "耐腐蚀"],
    disadvantages: ["脆性大", "加工困难"],
    processing_methods: ["烧结", "热压", "热等静压"],
    related_materials: ["氧化锆陶瓷", "碳化硅陶瓷"],
    tags: ["陶瓷", "耐磨"]
  },
  {
    id: "sic_ceramic",
    name_cn: "碳化硅陶瓷",
    name_en: "Silicon Carbide Ceramic",
    abbreviation: null,
    category_1: "无机非金属材料",
    category_2: "陶瓷",
    description:
      "碳化硅陶瓷具有高硬度、高导热和耐磨性，常用于磨料、耐火材料和半导体衬底。",
    properties: ["高硬度", "高导热", "耐磨", "耐高温"],
    applications: ["磨料", "机械密封", "散热器", "半导体基片"],
    advantages: ["耐磨", "导热性好"],
    disadvantages: ["脆性大", "加工困难"],
    processing_methods: ["烧结", "热压", "化学气相沉积"],
    related_materials: ["氧化铝陶瓷", "氮化硅陶瓷"],
    tags: ["陶瓷", "导热"]
  },
  {
    id: "carbon_fiber_composite",
    name_cn: "碳纤维复合材料",
    name_en: "Carbon Fiber Composite",
    abbreviation: null,
    category_1: "复合材料",
    category_2: "纤维增强复合材料",
    description:
      "碳纤维复合材料由碳纤维增强体和树脂基体构成，具有高强度、低密度和优异的疲劳性能，是重要的轻量化材料。",
    properties: ["高比强度", "高比模量", "低密度", "耐疲劳"],
    applications: ["航空航天", "赛车", "风电叶片", "体育用品"],
    advantages: ["强度高", "重量轻"],
    disadvantages: ["成本高", "易脆断"],
    processing_methods: ["真空浸渍", "自动铺丝", "热压固化"],
    related_materials: ["玻璃纤维复合材料", "芳纶复合材料"],
    tags: ["复合材料", "轻量化"]
  },
  {
    id: "glass_fiber_composite",
    name_cn: "玻璃纤维复合材料",
    name_en: "Glass Fiber Composite",
    abbreviation: null,
    category_1: "复合材料",
    category_2: "纤维增强复合材料",
    description:
      "玻璃纤维复合材料成本低、强度较高、电绝缘性好，广泛用于建材、汽车和电子领域。",
    properties: ["高强度", "电绝缘", "耐腐蚀"],
    applications: ["风电叶片", "船体", "电路板", "车身零件"],
    advantages: ["成本低", "耐腐蚀"] ,
    disadvantages: ["密度较大", "疲劳性能一般"],
    processing_methods: ["手糊成型", "喷射成型", "RTM"],
    related_materials: ["碳纤维复合材料", "芳纶复合材料"],
    tags: ["复合材料", "经济"]
  },
  {
    id: "lifepo4",
    name_cn: "磷酸铁锂",
    name_en: "Lithium Iron Phosphate",
    abbreviation: null,
    category_1: "新能源材料",
    category_2: "锂电正极材料",
    description:
      "磷酸铁锂是一种锂离子电池正极材料，具有安全性高、循环寿命长的特点，主要用于动力电池。",
    properties: ["安全性高", "寿命长", "成本相对低"],
    applications: ["电动汽车电池", "储能电站"],
    advantages: ["循环稳定", "耐高温"],
    disadvantages: ["能量密度略低"],
    processing_methods: ["固相合成", "碳包覆"],
    related_materials: ["三元正极材料", "钛酸锂"],
    tags: ["新能源", "安全"]
  },
  {
    id: "graphite_anode",
    name_cn: "石墨负极",
    name_en: "Graphite Anode",
    abbreviation: null,
    category_1: "新能源材料",
    category_2: "锂电负极材料",
    description:
      "石墨负极是目前锂离子电池最常用的负极材料，具有较好的充放电稳定性和导电性。",
    properties: ["导电性好", "倍率性能适中", "成本低"],
    applications: ["锂离子电池", "超级电容器"],
    advantages: ["成熟技术", "成本低"],
    disadvantages: ["能量密度有限", "倍率性能一般"],
    processing_methods: ["石油焦煅烧", "球化"],
    related_materials: ["硅碳负极", "硬碳"],
    tags: ["新能源", "负极"]
  },
  {
    id: "perovskite_solar",
    name_cn: "钙钛矿太阳能材料",
    name_en: "Perovskite Solar Material",
    abbreviation: null,
    category_1: "新能源材料",
    category_2: "光伏材料",
    description:
      "钙钛矿太阳能材料具有高光吸收系数和长载流子寿命，是新一代高效率光伏材料的代表。",
    properties: ["高光电转换效率", "制造成本低"],
    applications: ["光伏电池", "光电探测器"],
    advantages: ["制备简单", "性能提升快"],
    disadvantages: ["稳定性差", "含铅问题"],
    processing_methods: ["溶液旋涂", "蒸发沉积"],
    related_materials: ["晶硅太阳能", "钙钛矿量子点"],
    tags: ["新能源", "光伏"]
  }
];

// 根据材料数据生成一级分类列表
function getCategories(data) {
  const set = new Set();
  data.forEach((item) => {
    set.add(item.category_1);
  });
  return ["全部", ...Array.from(set)];
}

// 渲染分类按钮
function renderCategories() {
  const categories = getCategories(materialsData);
  const nav = document.getElementById("categories");
  nav.innerHTML = "";
  categories.forEach((cat) => {
    const btn = document.createElement("button");
    btn.className = "category-btn";
    btn.textContent = cat;
    btn.dataset.category = cat;
    btn.addEventListener("click", () => {
      document
        .querySelectorAll(".category-btn")
        .forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      currentCategory = cat;
      filterAndRender();
    });
    nav.appendChild(btn);
  });
  // 默认激活第一个分类
  nav.querySelector(".category-btn").classList.add("active");
}

let currentCategory = "全部";
let searchKeyword = "";

// 根据当前分类和搜索关键字过滤数据
function filterMaterials() {
  return materialsData.filter((item) => {
    const matchCategory =
      currentCategory === "全部" || item.category_1 === currentCategory;
    const keyword = searchKeyword.trim().toLowerCase();
    const matchKeyword = keyword
      ? [
          item.name_cn,
          item.name_en,
          item.abbreviation || "",
          item.description,
          ...(item.tags || []),
          ...(item.properties || []),
          ...(item.applications || []),
        ]
          .join(" ")
          .toLowerCase()
          .includes(keyword)
      : true;
    return matchCategory && matchKeyword;
  });
}

// 渲染材料列表卡片
function renderMaterialList(list) {
  const container = document.getElementById("material-list");
  container.innerHTML = "";
  list.forEach((mat) => {
    const card = document.createElement("div");
    card.className = "material-card";
    const abbrev = mat.abbreviation ? ` (${mat.abbreviation})` : "";
    const shortDesc = mat.description
      .replace(/\n/g, " ")
      .slice(0, 60);
    const ellipsis = mat.description.length > 60 ? "…" : "";
    card.innerHTML = `<h3>${mat.name_cn}${abbrev}</h3><p>${shortDesc}${ellipsis}</p>`;
    card.addEventListener("click", () => {
      showMaterialDetail(mat);
    });
    container.appendChild(card);
  });
  document.getElementById("material-detail").classList.add("hidden");
  container.style.display = "grid";
}

// 显示材料详情
function showMaterialDetail(mat) {
  const detail = document.getElementById("material-detail");
  detail.classList.remove("hidden");
  detail.innerHTML = "";
  // 返回按钮
  const backBtn = document.createElement("button");
  backBtn.textContent = "← 返回列表";
  backBtn.style.marginBottom = "1rem";
  backBtn.style.backgroundColor = "#e0e7ff";
  backBtn.style.color = "#2a3eb1";
  backBtn.style.border = "none";
  backBtn.style.padding = "0.5rem 1rem";
  backBtn.style.borderRadius = "20px";
  backBtn.style.cursor = "pointer";
  backBtn.addEventListener("click", () => {
    detail.classList.add("hidden");
    document.getElementById("material-list").style.display = "grid";
  });
  detail.appendChild(backBtn);
  // 标题
  const title = document.createElement("h2");
  title.textContent = `${mat.name_cn}${
    mat.abbreviation ? ` (${mat.abbreviation})` : ""
  }`;
  detail.appendChild(title);
  // 基本信息
  const baseInfo = document.createElement("p");
  baseInfo.innerHTML = `<strong>英文名:</strong> ${mat.name_en}<br/><strong>所属分类:</strong> ${mat.category_1} / ${mat.category_2}`;
  detail.appendChild(baseInfo);
  // 描述
  const desc = document.createElement("p");
  desc.textContent = mat.description;
  detail.appendChild(desc);
  // 相关属性块
  function createSection(titleText, items) {
    if (!items || items.length === 0) return;
    const sectionTitle = document.createElement("h3");
    sectionTitle.textContent = titleText;
    detail.appendChild(sectionTitle);
    const ul = document.createElement("ul");
    items.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      ul.appendChild(li);
    });
    detail.appendChild(ul);
  }
  createSection("主要性能", mat.properties);
  createSection("典型用途", mat.applications);
  createSection("优点", mat.advantages);
  createSection("缺点", mat.disadvantages);
  createSection("加工方法", mat.processing_methods);
  createSection("相关材料", mat.related_materials);
  // 标签
  if (mat.tags && mat.tags.length > 0) {
    const tagContainer = document.createElement("p");
    mat.tags.forEach((tag) => {
      const span = document.createElement("span");
      span.className = "badge";
      span.textContent = tag;
      tagContainer.appendChild(span);
    });
    detail.appendChild(tagContainer);
  }
  // 隐藏列表
  document.getElementById("material-list").style.display = "none";
}

function filterAndRender() {
  const filtered = filterMaterials();
  renderMaterialList(filtered);
}

// 搜索输入监听
function setupSearch() {
  const input = document.getElementById("search-input");
  input.addEventListener("input", () => {
    searchKeyword = input.value;
    filterAndRender();
  });
}

// 初始化
function init() {
  renderCategories();
  setupSearch();
  filterAndRender();
}

// 页面加载完成后初始化
window.addEventListener("DOMContentLoaded", init);